#!/usr/bin/env python

import my_hello
my_hello.world()